# XYZet Client release qoidalari.
# ZXing reflection ishlatmaydi, lekin QR dekoderi barqaror ishlashi uchun saqlanadi.
-keep class com.google.zxing.** { *; }
