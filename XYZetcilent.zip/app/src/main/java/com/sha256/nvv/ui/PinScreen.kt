package com.sha256.nvv.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sha256.nvv.crypto.Vault
import com.sha256.nvv.ui.theme.*
import kotlinx.coroutines.delay

enum class PinMode {
    CREATE,
    CONFIRM,
    UNLOCK
}

@Composable
fun PinScreen(
    mode: PinMode,
    isChangingPin: Boolean = false,
    onPinSuccess: () -> Unit,
    onCancel: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val vault = remember { Vault(context) }

    var currentMode by remember { mutableStateOf(mode) }
    var enteredPin by remember { mutableStateOf("") }
    var firstEnteredPin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var remainingLockout by remember { mutableStateOf(vault.getLockoutRemainingSeconds()) }

    // Lockout countdown timer
    LaunchedEffect(remainingLockout) {
        while (remainingLockout > 0) {
            delay(1000)
            remainingLockout = vault.getLockoutRemainingSeconds()
        }
    }

    val titleText = when (currentMode) {
        PinMode.CREATE -> if (isChangingPin) "Yangi PIN kodni kiriting" else "4 xonali PIN kod yarating"
        PinMode.CONFIRM -> "PIN kodni qayta kiriting"
        PinMode.UNLOCK -> "PIN kodni kiriting"
    }

    val subtitleText = when (currentMode) {
        PinMode.CREATE -> "Ilovani xavfsiz himoyalash uchun"
        PinMode.CONFIRM -> "Tasdiqlash uchun bir xil kodni kiriting"
        PinMode.UNLOCK -> "Ilovaga kirish uchun PIN kod"
    }

    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun handleDigit(digit: String) {
        if (remainingLockout > 0 || busy) return
        if (enteredPin.length < 4) {
            val newPin = enteredPin + digit
            enteredPin = newPin
            errorMessage = null

            if (newPin.length == 4) {
                busy = true
                scope.launch {
                // 4-katak yashil bo'lib ko'rinishi uchun qisqa kutish
                kotlinx.coroutines.delay(180)
                when (currentMode) {
                    PinMode.CREATE -> {
                        firstEnteredPin = newPin
                        enteredPin = ""
                        currentMode = PinMode.CONFIRM
                    }
                    PinMode.CONFIRM -> {
                        if (newPin == firstEnteredPin) {
                            vault.setPin(newPin)
                            onPinSuccess()
                        } else {
                            errorMessage = "PIN kodlar mos kelmadi! Qaytadan kiriting."
                            enteredPin = ""
                            firstEnteredPin = ""
                            currentMode = PinMode.CREATE
                        }
                    }
                    PinMode.UNLOCK -> {
                        val valid = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { vault.verifyPin(newPin) }
                        if (valid) {
                            onPinSuccess()
                        } else {
                            val lockout = vault.getLockoutRemainingSeconds()
                            remainingLockout = lockout
                            if (lockout > 0) {
                                errorMessage = "Ko'p xato urinish! $lockout soniya kuting."
                            } else {
                                errorMessage = "PIN kod noto'g'ri!"
                            }
                            enteredPin = ""
                        }
                    }
                }
                busy = false
                }
            }
        }
    }

    fun handleBackspace() {
        if (busy) return
        if (enteredPin.isNotEmpty()) {
            enteredPin = enteredPin.dropLast(1)
            errorMessage = null
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = PureWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 36.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(MintCard)
                        .border(1.5.dp, AccentGreen, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = AccentGreen,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = titleText,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = subtitleText,
                    fontSize = 14.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(28.dp))

                // PIN dots indicator
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(4) { index ->
                        val isFilled = index < enteredPin.length
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(if (isFilled) AccentGreen else BorderLight)
                                .border(1.5.dp, if (isFilled) AccentGreen else BorderLight, CircleShape)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Error / Lockout Message
                AnimatedVisibility(visible = remainingLockout > 0 || errorMessage != null) {
                    if (remainingLockout > 0) {
                        Text(
                            text = "Bloklandi! Qayta urinish: $remainingLockout s",
                            color = RedAlert,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center
                        )
                    } else if (errorMessage != null) {
                        Text(
                            text = errorMessage ?: "",
                            color = RedAlert,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Custom 3x4 Keypad
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val rows = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("cancel", "0", "back")
                )

                for (row in rows) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        for (key in row) {
                            when (key) {
                                "cancel" -> {
                                    if (onCancel != null && isChangingPin) {
                                        Box(
                                            modifier = Modifier
                                                .size(72.dp)
                                                .clip(CircleShape)
                                                .clickable { onCancel() },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "Bekor",
                                                fontSize = 14.sp,
                                                color = TextSecondary
                                            )
                                        }
                                    } else {
                                        Spacer(modifier = Modifier.size(72.dp))
                                    }
                                }
                                "back" -> {
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(CircleShape)
                                            .background(KeypadBg)
                                            .clickable(enabled = remainingLockout == 0L) { handleBackspace() },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Backspace,
                                            contentDescription = "O'chirish",
                                            tint = TextPrimary,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                                else -> {
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(CircleShape)
                                            .background(KeypadBg)
                                            .clickable(enabled = remainingLockout == 0L) { handleDigit(key) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = key,
                                            fontSize = 24.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = TextPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
