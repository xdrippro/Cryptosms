package com.sha256.nvv.sms

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import androidx.core.app.NotificationCompat
import com.sha256.nvv.MainActivity
import com.sha256.nvv.R
import com.sha256.nvv.crypto.Protocol
import com.sha256.nvv.crypto.Vault
import com.sha256.nvv.data.MessageStore
import com.sha256.nvv.data.UiMessage

class SmsReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID = "cryptosms_channel"
        const val CHANNEL_NAME = "XYZet Client xabarlari"
        private var notificationId = 1000
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        val vault = Vault(context)
        val config = vault.getTrackerConfig() ?: return // Not paired yet

        val fullBodyBuilder = StringBuilder()
        var senderNumber: String? = null

        for (sms in messages) {
            if (senderNumber == null) {
                senderNumber = sms.displayOriginatingAddress ?: sms.originatingAddress
            }
            fullBodyBuilder.append(sms.displayMessageBody ?: sms.messageBody ?: "")
        }

        val fullBody = fullBodyBuilder.toString().trim()
        val sender = senderNumber ?: return

        // QR'dagi raqam = MONITORING telefon raqami (tracker hisobotni shu raqamga yuboradi).
        // Tracker SIM raqami QR'da yo'q: shifrlangan SMS AES-GCM kalit bilan tasdiqlanadi (kalitsiz soxta SMS ochilmaydi),
        // shuning uchun jo'natuvchi raqami faqat buyruq manzili sifatida eslab qolinadi.
        val senderLast9 = Protocol.last9(sender)
        // Faqat foydalanuvchi kiritgan GPS Tracker raqamidan kelgan SMS qabul qilinadi
        if (config.simPhone9.length != 9 || senderLast9 != config.simPhone9) return

        val messageStore = MessageStore(context)
        val nowSec = System.currentTimeMillis() / 1000

        // 1. Check if encrypted
        if (Protocol.looksEncrypted(fullBody)) {
            val decrypted = Protocol.decryptIncoming(fullBody, config.keyBytes)
            if (decrypted != null) {
                when (decrypted) {
                    is Protocol.IncomingMessage.N1Location -> {
                        val lastTs = vault.getLastAcceptedTsN1()
                        if (decrypted.timestampSec > lastTs) {
                            vault.setLastAcceptedTsN1(decrypted.timestampSec)
                            val uiMsg = UiMessage(
                                type = "N1",
                                timestampSec = decrypted.timestampSec,
                                latitude = decrypted.latitude,
                                longitude = decrypted.longitude,
                                mapsUrl = decrypted.mapsUrl,
                                bodyText = String.format(java.util.Locale.US, "%.7f, %.7f", decrypted.latitude, decrypted.longitude)
                            )
                            messageStore.addMessage(uiMsg)
                            showNotification(
                                context,
                                title = "GPS Tracker: ${config.name}",
                                text = "Yangi joylashuv qabul qilindi: ${decrypted.latitude}, ${decrypted.longitude}"
                            )
                        }
                    }

                    is Protocol.IncomingMessage.G7Alert -> {
                        val lastTs = vault.getLastAcceptedTsG7()
                        if (decrypted.timestampSec > lastTs) {
                            vault.setLastAcceptedTsG7(decrypted.timestampSec)
                            val uiMsg = UiMessage(
                                type = "G7",
                                timestampSec = decrypted.timestampSec,
                                bodyText = decrypted.message
                            )
                            messageStore.addMessage(uiMsg)
                            showNotification(
                                context,
                                title = "GPS Tracker: ${config.name}",
                                text = "OGOHLANTIRISH: ${decrypted.message}"
                            )
                        }
                    }

                    is Protocol.IncomingMessage.Hello -> {
                        if (decrypted.timestampSec > vault.getLastAcceptedTsHello()) {
                            vault.setLastAcceptedTsHello(decrypted.timestampSec)
                            messageStore.addMessage(
                                UiMessage(
                                    type = "ULANISH",
                                    timestampSec = decrypted.timestampSec,
                                    bodyText = "Tracker bilan ulanish o'rnatildi: " +
                                        Protocol.formatUzPhone(config.simPhone9)
                                )
                            )
                            showNotification(context, "GPS Tracker: ${config.name}", "Tracker bilan ulanish o'rnatildi")
                        }
                    }

                    else -> {
                        // Silently ignore unknown types
                    }
                }
            }
            return
        }

        // 2. Plaintext fallback if body starts with "GPS Tracker:"
        // Ochiq matn: jo'natuvchi raqami yuqorida allaqachon tekshirilgan
        val fallback = Protocol.parsePlaintextFallback(fullBody, nowSec)
        if (fallback != null) {
            val uiMsg = UiMessage(
                type = "OCHIQ",
                timestampSec = fallback.timestampSec,
                mapsUrl = fallback.mapsUrl,
                bodyText = fallback.body
            )
            messageStore.addMessage(uiMsg)
            showNotification(
                context,
                title = "GPS Tracker: ${config.name}",
                text = fallback.body
            )
        }
    }

    private fun showNotification(context: Context, title: String, text: String) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "GPS Tracker xabarlari"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(notificationId++, notification)
    }
}
