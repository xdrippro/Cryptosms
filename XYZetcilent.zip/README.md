# XYZet Client (Native Android)

**XYZet Client** (`com.sha256.nvv`, v1.2.0) — "GPS Tracker" (`com.gpstracker.app`) ilovasi uchun shifrlangan monitoring va masofaviy boshqaruv hamrohi.

---

## Asosiy xususiyatlari

- **Offline va xavfsiz**: `INTERNET` ruxsati yo'q, tarmoqqa so'rovlar yuborilmaydi, analitika mavjud emas.
- **QR orqali tezkor bog'lanish**: GPS Tracker ekranidagi QR kodni CameraX va ZXing yordamida skanerlab 32-baytli AES-256 kalit, telefon raqami va maxfiy parolni xavfsiz bog'laydi.
- **AES-256-GCM shifrlash**:
  - Tracker -> Monitor: AAD = `0x01`
  - Monitor -> Tracker: AAD = `0x02`
  - Wire formati: Base64(IV[12] + Ciphertext + Tag[16])
- **N1 Joylashuv protokoli**: 13 baytli binar paket, 7 xonali Google Maps havolasi (`https://maps.google.com/?q=lat,lng`).
- **G7 Ogohlantirish**: Qurilma administratori o'chirilganda darhol qizil ogohlantirish ko'rsatish.
- **Buyruqlar**:
  - `JOY` (0x10) — Joriy koordinatani so'rash (rate limit: 10s, javob 5 daqiqada 1 marta keladi).
  - `JOY OVOZ` (0x11) — Telefon sirenasini chaldirish (tasdiqlash muloqot oynasi bilan).
- **Xavfsizlik**:
  - `FLAG_SECURE`: Skrinshotlar va ekran yozuvlari bloklangan.
  - Android Keystore master kaliti orqali barcha ma'lumotlar SharedPreferences'da shifrlangan holda saqlanadi.
  - 4 xonali PIN kod (PBKDF2-HMAC-SHA256, 100 000 iteratsiya), 5 ta xato urinishdan so'ng vaqtli bloklash.
  - Fondan 60 soniya o'tgach avtomatik qulflash.

---

## Qurish (Release)

Gradle 9.6.0 va Android Gradle Plugin 9.4.0 (Kotlin Compose Compiler 2.3.21). Release APK R8 bilan kichraytiriladi va **imzolanmagan** chiqadi: o'rnatishdan oldin o'zingiz imzolang.

1. Loyihani GitHub reposiga yuklang (`main` branch).
2. **Actions -> Build Release APK -> Run workflow**.
3. Yakunlangach **Artifacts** dan `XYZet-Client-unsigned` ni yuklab oling (`XYZet-Client-1.2.0-unsigned.apk`).

`v1.2.0` kabi tag push qilsangiz, APK **Releases** bo'limiga ham chiqadi.
