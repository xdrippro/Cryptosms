package com.sha256.nvv

import android.Manifest
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.sha256.nvv.crypto.Protocol
import com.sha256.nvv.crypto.Vault
import com.sha256.nvv.data.MessageStore
import com.sha256.nvv.ui.*
import com.sha256.nvv.ui.theme.CryptoSmsTheme
import com.sha256.nvv.ui.theme.PureWhite

sealed class Screen {
    object FirstLaunch : Screen()
    object QrScanner : Screen()
    object Main : Screen()
    object Settings : Screen()
    data class ChangePin(val isChanging: Boolean = true) : Screen()
}

@Composable
fun AppRoot(
    isUnlocked: Boolean,
    onUnlock: () -> Unit
) {
    val context = LocalContext.current
    val vault = remember { Vault(context) }
    val messageStore = remember { MessageStore(context) }

    var currentScreen by remember { mutableStateOf<Screen>(Screen.FirstLaunch) }
    var trackerConfig by remember { mutableStateOf(vault.getTrackerConfig()) }
    var hasPinCreated by remember { mutableStateOf(vault.hasPin()) }

    // Launcher for SMS permissions after pairing
    val smsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Permissions handled
    }

    // Determine initial screen when unlocked
    LaunchedEffect(isUnlocked, trackerConfig) {
        if (isUnlocked) {
            val cfg = vault.getTrackerConfig()
            trackerConfig = cfg
            if (cfg != null) {
                if (currentScreen is Screen.FirstLaunch || currentScreen is Screen.QrScanner) {
                    currentScreen = Screen.Main
                }
            } else {
                currentScreen = Screen.FirstLaunch
            }
        }
    }

    CryptoSmsTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = PureWhite
        ) {
            if (!hasPinCreated) {
                // Must create PIN on first run
                PinScreen(
                    mode = PinMode.CREATE,
                    isChangingPin = false,
                    onPinSuccess = {
                        hasPinCreated = true
                        onUnlock()
                    }
                )
            } else if (!isUnlocked) {
                // Ask for PIN to unlock
                PinScreen(
                    mode = PinMode.UNLOCK,
                    onPinSuccess = {
                        onUnlock()
                    }
                )
            } else {
                // Authenticated user flows
                when (val screen = currentScreen) {
                    is Screen.FirstLaunch -> {
                        FirstLaunchScreen(
                            onScanQrClick = {
                                currentScreen = Screen.QrScanner
                            }
                        )
                    }

                    is Screen.QrScanner -> {
                        QrScannerScreen(
                            onSuccess = { cfg ->
                                vault.saveTrackerConfig(cfg)
                                trackerConfig = cfg
                                // Request SMS permissions step by step after pairing
                                smsPermissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.RECEIVE_SMS,
                                        Manifest.permission.SEND_SMS
                                    )
                                )
                                currentScreen = Screen.Main
                            },
                            onCancel = {
                                currentScreen = if (vault.isTrackerPaired()) Screen.Main else Screen.FirstLaunch
                            }
                        )
                    }

                    is Screen.Main -> {
                        val cfg = trackerConfig ?: vault.getTrackerConfig()
                        if (cfg != null && cfg.simPhone9.length != 9) {
                            TrackerPhoneScreen(
                                trackerName = cfg.name,
                                onSave = { p ->
                                    vault.setTrackerSim(p)
                                    trackerConfig = vault.getTrackerConfig()
                                },
                                onCancel = {
                                    vault.clearTrackerConfig()
                                    messageStore.clearMessages()
                                    trackerConfig = null
                                    currentScreen = Screen.FirstLaunch
                                }
                            )
                        } else if (cfg != null) {
                            MainScreen(
                                trackerConfig = cfg,
                                messageStore = messageStore,
                                onOpenSettings = {
                                    currentScreen = Screen.Settings
                                }
                            )
                        } else {
                            currentScreen = Screen.FirstLaunch
                        }
                    }

                    is Screen.Settings -> {
                        val cfg = trackerConfig ?: vault.getTrackerConfig()
                        if (cfg != null) {
                            SettingsScreen(
                                trackerConfig = cfg,
                                onBack = { currentScreen = Screen.Main },
                                onRebindQr = { currentScreen = Screen.QrScanner },
                                onChangePin = { currentScreen = Screen.ChangePin(true) },
                                onSaveSim = { p ->
                                    vault.setTrackerSim(p)
                                    trackerConfig = vault.getTrackerConfig()
                                },
                                onUnbind = {
                                    vault.clearTrackerConfig()
                                    messageStore.clearMessages()
                                    trackerConfig = null
                                    currentScreen = Screen.FirstLaunch
                                }
                            )
                        } else {
                            currentScreen = Screen.FirstLaunch
                        }
                    }

                    is Screen.ChangePin -> {
                        PinScreen(
                            mode = PinMode.CREATE,
                            isChangingPin = true,
                            onPinSuccess = {
                                currentScreen = Screen.Settings
                            },
                            onCancel = {
                                currentScreen = Screen.Settings
                            }
                        )
                    }
                }
            }
        }
    }
}
