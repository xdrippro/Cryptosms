package com.sha256.nvv.sms

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.sha256.nvv.crypto.Protocol
import com.sha256.nvv.crypto.Vault

object SmsSender {

    const val ACTION_SMS_SENT = "com.sha256.nvv.SMS_SENT_ACTION"
    private const val RATE_LIMIT_MS = 10_000L

    private var lastJoySentTime = 0L
    private var lastJoyOvozSentTime = 0L

    sealed class SendResult {
        object Success : SendResult()
        data class RateLimited(val remainingSec: Int) : SendResult()
        data class Error(val message: String) : SendResult()
    }

    fun canSendCommand(type: Byte): Pair<Boolean, Int> {
        val now = System.currentTimeMillis()
        val lastTime = if (type == Protocol.TYPE_CMD_JOY) lastJoySentTime else lastJoyOvozSentTime
        val elapsed = now - lastTime
        return if (elapsed < RATE_LIMIT_MS) {
            val waitSec = ((RATE_LIMIT_MS - elapsed + 999) / 1000).toInt()
            Pair(false, waitSec)
        } else {
            Pair(true, 0)
        }
    }

    fun sendCommand(
        context: Context,
        type: Byte,
        onStatus: (Boolean, String) -> Unit
    ): SendResult {
        val (allowed, remainingSec) = canSendCommand(type)
        if (!allowed) {
            return SendResult.RateLimited(remainingSec)
        }

        val vault = Vault(context)
        val config = vault.getTrackerConfig()
            ?: return SendResult.Error("Tracker bog'lanmagan!")
        if (config.simPhone9.length != 9) {
            return SendResult.Error("Tracker telefon raqami noma'lum. Sozlamalarda kiriting yoki tracker birinchi SMS yuborishini kuting.")
        }
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.SEND_SMS)
            != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            return SendResult.Error("SMS yuborish ruxsati berilmagan (telefon sozlamalaridan bering).")
        }

        val nowSec = System.currentTimeMillis() / 1000
        val lastSent = vault.getLastSentTs()
        val ts = maxOf(nowSec, lastSent + 1)
        vault.setLastSentTs(ts)

        if (type == Protocol.TYPE_CMD_JOY) {
            lastJoySentTime = System.currentTimeMillis()
        } else {
            lastJoyOvozSentTime = System.currentTimeMillis()
        }

        val encryptedBody = Protocol.buildAndEncryptCommand(
            type = type,
            tsSec = ts,
            code4 = config.code4,
            keyBytes = config.keyBytes
        )

        val destination = "+998" + config.simPhone9

        val action = ACTION_SMS_SENT + "." + type.toInt()
        val sentIntent = Intent(action).setPackage(context.packageName)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            type.toInt(),
            sentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Register one-time receiver for sent result
        val sentReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                try {
                    c.unregisterReceiver(this)
                } catch (_: Exception) {}

                when (resultCode) {
                    Activity.RESULT_OK -> {
                        onStatus(true, "Buyruq yuborildi")
                    }
                    SmsManager.RESULT_ERROR_NO_SERVICE -> {
                        onStatus(false, "Aloqa tarmog'i mavjud emas")
                    }
                    SmsManager.RESULT_ERROR_RADIO_OFF -> {
                        onStatus(false, "Parvoz rejimi yoqilgan")
                    }
                    else -> {
                        onStatus(false, "SMS yuborishda xatolik yuz berdi")
                    }
                }
            }
        }

        ContextCompat.registerReceiver(
            context.applicationContext,
            sentReceiver,
            IntentFilter(action),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getDefault()
        }

        return try {
            smsManager.sendTextMessage(destination, null, encryptedBody, pendingIntent, null)
            SendResult.Success
        } catch (e: Exception) {
            try {
                context.applicationContext.unregisterReceiver(sentReceiver)
            } catch (_: Exception) {}
            SendResult.Error(e.message ?: "SMS yuborilmadi")
        }
    }
}
