package com.sha256.nvv

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import com.sha256.nvv.crypto.Vault

class MainActivity : ComponentActivity() {

    private val isUnlocked = mutableStateOf(false)
    private var backgroundTimestamp = 0L

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Notification permission handled
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Security: FLAG_SECURE prevents screenshots, screen recording, and task switcher previews
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        // Request notification permission on first launch if Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val vault = Vault(this)
        if (!vault.hasPin()) {
            // First run, PIN creation needed immediately
            isUnlocked.value = true
        }

        setContent {
            AppRoot(
                isUnlocked = isUnlocked.value,
                onUnlock = {
                    isUnlocked.value = true
                }
            )
        }
    }

    override fun onStop() {
        super.onStop()
        backgroundTimestamp = System.currentTimeMillis()
    }

    override fun onResume() {
        super.onResume()
        val vault = Vault(this)
        if (vault.hasPin() && backgroundTimestamp > 0L) {
            val elapsed = System.currentTimeMillis() - backgroundTimestamp
            // Require PIN again after 60 seconds in background
            if (elapsed > 60_000L) {
                isUnlocked.value = false
            }
        }
        backgroundTimestamp = 0L
    }
}
