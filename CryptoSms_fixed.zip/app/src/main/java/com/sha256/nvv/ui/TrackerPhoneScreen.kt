package com.sha256.nvv.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sha256.nvv.ui.theme.*

/** QR skanerlangandan keyin: GPS Tracker telefonining SIM raqamini kiritish (majburiy). */
@Composable
fun TrackerPhoneScreen(
    trackerName: String,
    onSave: (String) -> Unit,
    onCancel: () -> Unit
) {
    var input by remember { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Bog'landi ✔", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = AccentGreen)
        Spacer(Modifier.height(8.dp))
        Text("Tracker: $trackerName", fontSize = 15.sp, color = TextSecondary)
        Spacer(Modifier.height(24.dp))
        Text(
            "GPS Tracker telefonining raqamini kiriting",
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Buyruqlar shu raqamga yuboriladi va faqat shu raqamdan kelgan xabarlar qabul qilinadi.",
            fontSize = 13.sp,
            color = TextSecondary
        )
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = input,
            onValueChange = { v ->
                val d = v.filter { it.isDigit() }
                input = (if (d.length > 9 && d.startsWith("998")) d.drop(3) else d).take(9)
            },
            label = { Text("Telefon raqami") },
            prefix = { Text("+998 ") },
            placeholder = { Text("XX XXX XX XX") },
            visualTransformation = UzPhoneTransformation(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { onSave(input) },
            enabled = input.length == 9,
            colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Saqlash") }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onCancel) { Text("Bekor qilish") }
    }
}

/** 9 ta raqamni "XX XXX XX XX" ko'rinishida ko'rsatadi (+998 alohida, o'zgarmas prefiks). */
class UzPhoneTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val d = text.text.take(9)
        val sb = StringBuilder()
        d.forEachIndexed { i, c ->
            if (i == 2 || i == 5 || i == 7) sb.append(' ')
            sb.append(c)
        }
        val mapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                val o = offset.coerceIn(0, d.length)
                return o + (if (o > 2) 1 else 0) + (if (o > 5) 1 else 0) + (if (o > 7) 1 else 0)
            }
            override fun transformedToOriginal(offset: Int): Int {
                val t = offset.coerceIn(0, sb.length)
                return (t - (if (t > 2) 1 else 0) - (if (t > 6) 1 else 0) - (if (t > 9) 1 else 0))
                    .coerceIn(0, d.length)
            }
        }
        return TransformedText(AnnotatedString(sb.toString()), mapping)
    }
}
