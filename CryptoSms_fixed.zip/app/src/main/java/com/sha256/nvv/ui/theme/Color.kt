package com.sha256.nvv.ui.theme

import androidx.compose.ui.graphics.Color

val MintCard = Color(0xFFEAFBF3)
val AccentGreen = Color(0xFF059669)
val AccentGreenDark = Color(0xFF047857)
val AccentGreenLight = Color(0xFFD1FAE5)

val RedAlert = Color(0xFFDC2626)
val RedAlertBg = Color(0xFFFEF2F2)

val PureWhite = Color(0xFFFFFFFF)
val SurfaceLight = Color(0xFFF9FAFB)
val TextPrimary = Color(0xFF111827)
val TextSecondary = Color(0xFF4B5563)
val BorderLight = Color(0xFFE5E7EB)
val KeypadBg = Color(0xFFF3F4F6)
