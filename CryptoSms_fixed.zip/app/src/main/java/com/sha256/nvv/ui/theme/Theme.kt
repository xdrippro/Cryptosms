package com.sha256.nvv.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
    primary = AccentGreen,
    onPrimary = PureWhite,
    primaryContainer = MintCard,
    onPrimaryContainer = AccentGreenDark,
    secondary = AccentGreenDark,
    onSecondary = PureWhite,
    error = RedAlert,
    onError = PureWhite,
    errorContainer = RedAlertBg,
    onErrorContainer = RedAlert,
    background = PureWhite,
    onBackground = TextPrimary,
    surface = PureWhite,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceLight,
    onSurfaceVariant = TextSecondary,
    outline = BorderLight
)

@Composable
fun CryptoSmsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}
