package com.sha256.nvv.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sha256.nvv.crypto.Protocol
import com.sha256.nvv.data.MessageStore
import com.sha256.nvv.data.UiMessage
import com.sha256.nvv.sms.SmsSender
import com.sha256.nvv.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    trackerConfig: Protocol.TrackerConfig,
    messageStore: MessageStore,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val messages by messageStore.messages.collectAsState()

    var showJoyOvozConfirmDialog by remember { mutableStateOf(false) }
    var isSendingCommand by remember { mutableStateOf(false) }

    fun sendCommand(type: Byte) {
        val result = SmsSender.sendCommand(context, type) { success, msg ->
            coroutineScope.launch {
                snackbarHostState.showSnackbar(msg)
            }
        }

        when (result) {
            is SmsSender.SendResult.Success -> {
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Buyruq jo'natilmoqda...")
                }
            }
            is SmsSender.SendResult.RateLimited -> {
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Iltimos, ${result.remainingSec} soniya kuting (cheklash: 10s)")
                }
            }
            is SmsSender.SendResult.Error -> {
                coroutineScope.launch {
                    snackbarHostState.showSnackbar(result.message)
                }
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(MintCard),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = AccentGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Crypto SMS",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = TextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Sozlamalar",
                            tint = TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PureWhite)
            )
        },
        containerColor = PureWhite
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            // Status Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MintCard),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Aloqa holati: BOG'LANGAN",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentGreenDark
                        )
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(AccentGreen)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Tracker: ${trackerConfig.name}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    val simNow = remember(messages.size, trackerConfig) { com.sha256.nvv.crypto.Vault(context).getTrackerSim() }
                    Text(
                        text = if (simNow.length == 9) "Tracker raqami: ${Protocol.formatUzPhone(simNow)}"
                               else "Tracker raqami: noma'lum (Sozlamalarda kiriting)",
                        fontSize = 14.sp,
                        color = TextSecondary
                    )

                    val lastMsg = messages.firstOrNull()
                    val lastTimeText = if (lastMsg != null) {
                        Protocol.formatDateTime(lastMsg.timestampSec)
                    } else {
                        "Xabar kelmagan"
                    }
                    Text(
                        text = "So'nggi aloqa: $lastTimeText",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            // Command Buttons
            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = { sendCommand(Protocol.TYPE_CMD_JOY) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentGreen)
            ) {
                Icon(imageVector = Icons.Default.LocationSearching, contentDescription = null, tint = PureWhite)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "JOY — Joylashuvni so'rash",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = PureWhite
                )
            }

            Text(
                text = "💡 Javob 5 daqiqada 1 marta keladi",
                fontSize = 12.sp,
                color = TextSecondary,
                modifier = Modifier
                    .padding(top = 4.dp, bottom = 8.dp)
                    .align(Alignment.CenterHorizontally)
            )

            Button(
                onClick = { showJoyOvozConfirmDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RedAlert)
            ) {
                Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null, tint = PureWhite)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "JOY OVOZ — Telefonni chaldirish",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = PureWhite
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // History Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Xabarlar tarixi (${messages.size})",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Message List
            if (messages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.MarkChatUnread,
                            contentDescription = null,
                            tint = BorderLight,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Hozircha xabarlar yo'q",
                            fontSize = 15.sp,
                            color = TextSecondary
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        MessageItem(msg = msg)
                    }
                }
            }
        }
    }

    // Confirmation dialog for JOY OVOZ
    if (showJoyOvozConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showJoyOvozConfirmDialog = false },
            title = {
                Text(
                    text = "Sirena yoqish",
                    fontWeight = FontWeight.Bold,
                    color = RedAlert
                )
            },
            text = {
                Text(text = "Telefonda sirena yoqiladi. Davom etasizmi?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showJoyOvozConfirmDialog = false
                        sendCommand(Protocol.TYPE_CMD_JOY_OVOZ)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedAlert)
                ) {
                    Text(text = "Ha, chaldirish", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showJoyOvozConfirmDialog = false }) {
                    Text(text = "Bekor qilish", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
fun MessageItem(msg: UiMessage) {
    val context = LocalContext.current

    when (msg.type) {
        "G7" -> {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = RedAlertBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, RedAlert)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BadgeLabel(text = "G7", bg = RedAlert, textColor = PureWhite)
                        Text(
                            text = Protocol.formatDateTime(msg.timestampSec),
                            fontSize = 12.sp,
                            color = RedAlert
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Qurilma administratori o'chirildi!",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = RedAlert
                    )
                }
            }
        }

        "N1" -> {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BadgeLabel(text = "N1", bg = AccentGreen, textColor = PureWhite)
                        Text(
                            text = Protocol.formatDateTime(msg.timestampSec),
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    if (msg.latitude != null && msg.longitude != null) {
                        Text(
                            text = "Kordinatalar: ${String.format(java.util.Locale.US, "%.7f, %.7f", msg.latitude, msg.longitude)}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextPrimary
                        )
                    }

                    if (!msg.mapsUrl.isNullOrEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = msg.mapsUrl,
                            fontSize = 12.sp,
                            color = AccentGreenDark,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(msg.mapsUrl))
                                runCatching { context.startActivity(intent) }
                            },
                            modifier = Modifier.height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentGreen)
                        ) {
                            Icon(imageVector = Icons.Default.Map, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Xaritada ochish", fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        else -> {
            // "OCHIQ" Plaintext fallback
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BadgeLabel(text = if (msg.type == "ULANISH") "ULANDI" else "OCHIQ", bg = Color(0xFFD97706), textColor = PureWhite)
                        Text(
                            text = Protocol.formatDateTime(msg.timestampSec),
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = msg.bodyText ?: "",
                        fontSize = 14.sp,
                        color = TextPrimary
                    )

                    if (!msg.mapsUrl.isNullOrEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(msg.mapsUrl))
                                runCatching { context.startActivity(intent) }
                            },
                            modifier = Modifier.height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentGreen)
                        ) {
                            Icon(imageVector = Icons.Default.Map, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Xaritada ochish", fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BadgeLabel(text: String, bg: Color, textColor: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}
