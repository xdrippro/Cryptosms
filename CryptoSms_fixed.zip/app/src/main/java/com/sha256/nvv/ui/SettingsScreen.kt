package com.sha256.nvv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sha256.nvv.crypto.Protocol
import com.sha256.nvv.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    trackerConfig: Protocol.TrackerConfig,
    onBack: () -> Unit,
    onRebindQr: () -> Unit,
    onChangePin: () -> Unit,
    onSaveSim: (String) -> Unit,
    onUnbind: () -> Unit
) {
    var showUnbindDialog by remember { mutableStateOf(false) }
    var simInput by remember(trackerConfig.simPhone9) { mutableStateOf(trackerConfig.simPhone9) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Sozlamalar",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = TextPrimary
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Ortga",
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PureWhite)
            )
        },
        containerColor = PureWhite
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                // Tracker Info Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MintCard),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = AccentGreen,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Bog'langan Tracker",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentGreenDark
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "Nomi: ${trackerConfig.name}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Sizning raqamingiz (tracker shu raqamga yuboradi): ${trackerConfig.formattedPhone()}",
                            fontSize = 13.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = simInput,
                            onValueChange = { v ->
                                val d = v.filter { it.isDigit() }
                                simInput = (if (d.length > 9 && d.startsWith("998")) d.drop(3) else d).take(9)
                            },
                            label = { Text("Tracker telefon raqami (9 raqam)") },
                            supportingText = { Text("Buyruqlar shu raqamga yuboriladi. Tracker birinchi SMS yuborganda o'zi to'ldiriladi.") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Button(
                            onClick = { onSaveSim(simInput) },
                            enabled = simInput.length == 9 && simInput != trackerConfig.simPhone9,
                            colors = ButtonDefaults.buttonColors(containerColor = AccentGreen)
                        ) {
                            Text("Saqlash")
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = BorderLight)
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = AccentGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Kalit saqlangan ✔",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = AccentGreenDark
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = AccentGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Parol saqlangan ✔",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = AccentGreenDark
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Actions Section
                Text(
                    text = "Boshqaruv",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )

                // Rebind QR
                OutlinedButton(
                    onClick = onRebindQr,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight)
                ) {
                    Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null, tint = AccentGreen)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = "Qayta bog'lash (QR)", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Change PIN
                OutlinedButton(
                    onClick = onChangePin,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight)
                ) {
                    Icon(imageVector = Icons.Default.LockReset, contentDescription = null, tint = AccentGreen)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = "PIN kodni o'zgartirish", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }

            // Unbind Button
            Button(
                onClick = { showUnbindDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RedAlert)
            ) {
                Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, tint = PureWhite)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Bog'lanishni o'chirish", color = PureWhite, fontWeight = FontWeight.SemiBold)
            }
        }
    }

    // Unbind confirmation dialog
    if (showUnbindDialog) {
        AlertDialog(
            onDismissRequest = { showUnbindDialog = false },
            title = {
                Text(
                    text = "Bog'lanishni o'chirish",
                    fontWeight = FontWeight.Bold,
                    color = RedAlert
                )
            },
            text = {
                Text(text = "Haqiqatan ham bog'lanishni va barcha xabarlar tarixini o'chirmoqchimisiz? Kalit va maxfiy kod to'liq tozalanadi.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showUnbindDialog = false
                        onUnbind()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedAlert)
                ) {
                    Text(text = "O'chirish", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnbindDialog = false }) {
                    Text(text = "Bekor qilish", color = TextSecondary)
                }
            }
        )
    }
}
