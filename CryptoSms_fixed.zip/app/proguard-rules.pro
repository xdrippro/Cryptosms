# Proguard rules for Crypto SMS

# ZXing QR Code
-keep class com.google.zxing.** { *; }

# Keep data models serialized to JSON
-keepclassmembers class com.sha256.nvv.data.** { *; }
-keep class com.sha256.nvv.data.** { *; }

# Keep crypto protocol classes
-keep class com.sha256.nvv.crypto.** { *; }
